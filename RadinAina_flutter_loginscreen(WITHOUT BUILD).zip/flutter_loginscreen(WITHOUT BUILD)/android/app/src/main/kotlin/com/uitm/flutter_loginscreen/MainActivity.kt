package com.uitm.flutter_loginscreen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
